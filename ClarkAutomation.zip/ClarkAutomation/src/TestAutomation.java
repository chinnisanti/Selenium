

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestAutomation {

	// Creating a driver object referencing WebDriver interface
	WebDriver driver;


	@Test
	public void TestCase1() throws InterruptedException {
		try {

			System.out.println("Start Automation Test cases of clark sign in page");
			// Setting the webdriver.chrome.driver property to its executable's
			// location
			System.setProperty("webdriver.chrome.driver", "D:/Naveen/Practice/Jars/chromedriver.exe");

			// Instantiating driver object and launching browser
			driver = new ChromeDriver();

			// Using get() method to open a webpage
			driver.get("http://.clark.de");

			// Click on Login Button
			Thread.sleep(2000);
			WebElement loginBtn = driver
					.findElement(By.xpath("//*[@class='page-navigation__link login-btn new_session']"));
			loginBtn.click();
			Thread.sleep(2000);
			driver.manage().window().maximize();
			// *******************************************************************************************************************************
			// Enter suer name and password and click on submit button to login
			// the application
			// *******************************************************************************************************************************
			driver.findElement(By.xpath("//input[@name='user[email]']")).sendKeys("steffen.glomb@posteo.de");
			driver.findElement(By.xpath("//input[@name='user[password]']")).sendKeys("Hallo123");
			driver.findElement(By.xpath("//input[@name='commit']")).click();
			Thread.sleep(5000);
			// *******************************************************************************************************************************
			// select the tab versichert In the tab �Vertr�ge� assert that there
			// are 3 contracts with �Gut versichert�
			// *******************************************************************************************************************************
			driver.findElement(By.xpath("//*[@href='/de/app/manager']")).click();
			Thread.sleep(5000);
			List<WebElement> allLinks = driver.findElements(By.xpath("//span[@class='_text_1trxuc']"));
			int total_GUTVERSICHERT = allLinks.size();
			 
			int count = 0;
			for (int i = 0; i < total_GUTVERSICHERT; i++) {
				 
				if (allLinks.get(i).getText().equals("GUT VERSICHERT")) {
					count++;
				}
			}
			System.out.println("total GUT VERSICHERT count=" + count);
			if (count == 3) {
				System.out.println("3 Gut versichert present in the Vertr�ge page");
				Assert.assertEquals(count, 3, "3 Gut versichert present in the  Vertr�ge page");
			} else {
				System.out.println("3 Gut versichert is not present in the Vertr�ge page");
				Assert.fail("3 Gut versichert is not present in the Vertr�ge page");
			}
			// *******************************************************************************************************************************
			// � In the tab �Rente� assert that �Dein Renteneinkommen� ist above
			// 2400 Euro
			// *******************************************************************************************************************************

			driver.findElement(By.xpath("//*[@href='/de/app/retirement']")).click();
			System.out.println("Rente tab clicked");
			Thread.sleep(8000);
			String Renteneinkommenvalue = driver
					.findElement(By.xpath("//*[@class='_actual-income__value_p57710 _value_p57710 _flex-item_p57710']"))
					.getText();

			String text = Renteneinkommenvalue;
			text = text.trim();
			String withoutLastCharacter = text.substring(0, text.length() - 1);

			String firstchar = withoutLastCharacter.substring(0, withoutLastCharacter.length() - 4);

			String finalword = firstchar.replace(".", "");
			int number = Integer.valueOf(finalword);

			if (number > 2400) {
				Assert.assertTrue(true);
				System.out.println("Renteneinkommenvalue "+ text +" is greater than 2400");

			} else {
				Assert.assertTrue(false);
				System.out.println("Renteneinkommenvalue is leass than 2400");
			}

			// *******************************************************************************************************************************
			// � In the tab �Bedarf� assert �Du hast alle empfohlenen Produkte!�
			// in the left column.
			// *******************************************************************************************************************************
			driver.findElement(By.xpath("//*[@href='/de/app/manager/recommendations']")).click();
			Thread.sleep(5000);
			driver.findElement(By
					.xpath("//button[@class='btn btn-primary manager__optimisations__numberone__rec__cta_container__cta']"))
					.click();
			Thread.sleep(8000);
			System.out.println("list of products presented are");
			Thread.sleep(1000);
			driver.navigate().back();
			Thread.sleep(8000);
			List<WebElement> listofprds = driver
					.findElements(By.xpath("//*[@class='manager__optimisations__optimisation__top-row__title']"));
			System.out.println("back to the products");
			int cnt = listofprds.size();
			System.out.println("list of products:" + cnt);
			Thread.sleep(5000);
 
			Assert.assertEquals(listofprds.get(0).getText(), "Bau�leis�tungs�ver�si�che�rung");
			Assert.assertEquals(listofprds.get(1).getText(), "Feu�er�roh�bau�ver�si�che�rung");
			Assert.assertEquals(listofprds.get(2).getText(), "Bau�her�ren-Haft�pflicht");
			System.out.println("Verified the product list left side column sucessfully as "+listofprds.get(0).getText() +","+listofprds.get(1).getText()+","+listofprds.get(2).getText());
		 
			Thread.sleep(2000);

			// *******************************************************************************************************************************
			// � Then click on �Clark jetzt empfehlen� and invite a friend via
			// email. Assert that the success message under the input field had
			// been shown.
			// *******************************************************************************************************************************
			driver.findElement(By.xpath("//*[@href='/de/app/invitations']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//input[@id='email']")).sendKeys("chinnisanti@gmail.com");
			Thread.sleep(1000);
			driver.findElement(By.xpath("//button[@id='sendInvitationEmail']")).click();
			Thread.sleep(3000);
			 String sucessmsg =driver.findElement(By.xpath("//*[@class='ig__success--wrapper ember-view']")).getText();
			 System.out.println("Sucess messgae after sending mail verification=="+sucessmsg);
			 if(!sucessmsg.isEmpty()){
				 Assert.assertEquals(sucessmsg, "erfolgreich versendet");
				 System.out.println("Sent email to friend ");
			 }
 
			
			// *******************************************************************************************************************************
			// Closing the browser
			  driver.quit();
		}

		catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
			System.out.println("****Failed the test case and ERROR MESSAGE END******");
		}

	}
}
